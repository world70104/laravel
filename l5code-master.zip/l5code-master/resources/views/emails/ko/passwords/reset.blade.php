비밀번호를 바꾸려면 브라우저에서 이 주소를 여세요: {{ route('reset.create', $token) }}
