Open the following Url to change your password: {{ route('reset.create', $token) }}
