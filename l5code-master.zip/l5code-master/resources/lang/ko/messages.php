<?php

return [
    'dashboard' => [
        'title' => '대시보드',
        'message' => '로그인 되었습니다!',
    ],

    'error' => [
        'title' => '죄송합니다. :(',
        'description' => '에러가 발생했습니다.',
        'not_found' => '요청하신 페이지가 없습니다.',

    ]
];