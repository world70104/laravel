<?php

return [
    'title' => '마크다운 뷰어',

    'messages' => [
        'not_found' => '요청하신 파일이 없습니다.',
    ],
];