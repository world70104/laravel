<?php

return [
    'title' => 'Markdown Viewer',

    'messages' => [
        'not_found' => 'File not found.',
    ],
];