<?php

return [
    'dashboard' => [
        'title' => 'Dashboard',
        'message' => 'You are logged in!',
    ],

    'error' => [
        'title' => 'Sorry. :(',
        'description' => 'Some bad thing happened.',
        'not_found' => 'Requested URL or resource does not exist.',

    ]
];