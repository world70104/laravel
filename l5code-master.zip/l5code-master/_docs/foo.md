# 이미지가 포함된 마크다운

![](images/foo-img-01.png)

그림 1 PHP 마스코트
